/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.jpaneuserinput;

import javax.swing.JOptionPane;

/**
 *
 * @author lsphe
 */
public class JpaneUserinput {

    public static void main(String[] args) {
        // Ask user for first number
        String num1 = JOptionPane.showInputDialog("Enter first number:");

        // Ask user for second number
        String num2 = JOptionPane.showInputDialog("Enter second number:");

        // Convert input (String) to numbers
        int number1 = Integer.parseInt(num1);
        int number2 = Integer.parseInt(num2);

        // Calculate sum
        int sum = number1 + number2;

        // Display result
        JOptionPane.showMessageDialog(null, "The sum is: " + sum);
    }
}
